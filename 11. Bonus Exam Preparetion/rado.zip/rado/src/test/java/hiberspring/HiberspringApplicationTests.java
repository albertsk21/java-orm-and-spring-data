package hiberspring;

import org.springframework.boot.test.context.SpringBootTest;
import org.testng.annotations.Test;

@SpringBootTest
class HiberspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
