package hiberspring.filepaths;


public final class FilesPaths {
    public static final String TOWN_JSON = "C:\\Intelji projects\\Java ORM and Spring Data\\11. Bonus Exam Preparetion\\rado\\src\\main\\resources\\files\\towns.json";
    public static final String BRANCHES_JSON = "C:\\Intelji projects\\Java ORM and Spring Data\\11. Bonus Exam Preparetion\\rado\\src\\main\\resources\\files\\branches.json";
    public static final String EMPLOYEE_CARDS_JSON =  "C:\\Intelji projects\\Java ORM and Spring Data\\11. Bonus Exam Preparetion\\rado\\src\\main\\resources\\files\\employee-cards.json";
    public static final String PRODUCTS_XML = "C:\\Intelji projects\\Java ORM and Spring Data\\11. Bonus Exam Preparetion\\rado\\src\\main\\resources\\files\\products.xml";
    public static final String EMPLOYEES_XML = "C:\\Intelji projects\\Java ORM and Spring Data\\11. Bonus Exam Preparetion\\rado\\src\\main\\resources\\files\\employees.xml";
}
